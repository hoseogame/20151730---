#pragma once
#include "Object.h"

class food : public Object
{
private:

public:
	food(int x = 0, int y = 0);
	virtual ~food();
};