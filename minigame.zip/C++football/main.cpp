#include"football.h"
#include"function.h"
#include"screen.h"

void Footballmain()
{
		f_function football_game;
}