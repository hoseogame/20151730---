#include <iostream>
#include "snakeGame.h"
#include "gotoxy.h"


using namespace std;

int S_main(void)
{
	
	
		SnakeGame EX;
		EX.Init();
		EX.Update();
		EX.Release();


	
	return 0;
}